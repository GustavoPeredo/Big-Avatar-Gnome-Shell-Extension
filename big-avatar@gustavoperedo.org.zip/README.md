# Big avatar Gnome Shell Extension
An extension based on https://github.com/db0x/bigavatar-db0x.de, it adds your avatar icon and name to the menu panel.

![screenshot](https://raw.githubusercontent.com/GustavoPeredo/Big-Avatar-Gnome-Shell-Extension/master/screenshot.png)

To do:

* Add different settings such as having an horizontal option and icon and font sizes.
* Auto-close menu when gnome-control-center opens.
